Mash is normally distributed as a dependency-free binary for Linux or OSX (see
https://github.com/marbl/Mash/releases). This source distribution is intended
for other operating systems or for development. Mash requires c++11 to build,
which is available in and GCC >= 4.8 and OSX >= 10.7.

See http://mash.readthedocs.org for more information.
